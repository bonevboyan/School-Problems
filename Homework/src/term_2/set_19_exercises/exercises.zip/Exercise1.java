package exercises;

import java.util.Scanner;

public class Exercise1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int a = scanner.nextInt();
        int[] broi = new int[10];
        for (int i = 0; i < a; i++) {
            int number = scanner.nextInt();
            broi[number]++;
        }
        for (int i = 0; i < 10; i++) {
            if(broi[i] != 0){
                System.out.println("chislo:" + i + " broi:" + broi[i]);
            }
        }
    }
}
