INSERT INTO Users VALUES
(1, 'viktor', '123', '11-11-2020'),
(2, 'blago', '123', '11-11-2020')

INSERT INTO Friends VALUEs 
(1, 2)

INSERT INTO Walls VALUES
(1, 1, 2, 'hehehehaw', '11-11-2020')

INSERT INTO Groups VALUES
(1, '12e', 'super 12e klasse')

INSERT INTO GroupMembers VALUES
(1, 1),
(2, 1)